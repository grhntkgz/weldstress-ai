# Bounded repair experiment

One S1 local trial was executed. It terminated after6 optimizer iterations, with objective0.000878214819 and maximum displacement0.0196508211 mm. Four interior midsides were eligible variables, but only Gmsh node86669 actually moved. Nodes86668,86670 and100559 remained byte-identical. Exact old/new coordinates and the full-coordinate audit are retained.

Optimizer success was not used as acceptance. One complete M1 candidate was saved and passed full independent qualification. S2 and S3 were not executed because the least invasive strategy succeeded. Twelve one-midside counterfactual calculations are root-cause diagnostics on individual elements, not repair trials or full mesh candidates. No random perturbation or global M1 remeshing occurred.
