# M2 quadratic quality

M2_C1 has193,962 nodes and109,737 Tet10 elements. Minimum SICN is0.0634291190 and minimum whole-mesh Q1 determinant is0.00450120191734 mm³. No negative/zero Q1 determinant or below0.020 SICN element was found. Global independent SICN agrees with Gmsh to5.575e-13.

Expanded909-point checks pass on51 selected elements around the original failure region and lowest-quality elements. Exact rational Bernstein bounds are positive on the16 lowest-SICN elements. Continuous positivity of all other elements is not claimed. Parameter-coordinate metadata warnings from Gmsh are preserved; the labelled discrete MSH round trip verifies exact nodes, connectivity, physical patch names and recomputed SICN. These warnings are not native ANSYS shape checks.
