# Historical failure reproduced

The original C02 M1 candidate was copied and independently reconstructed without overwriting E10. Its 145,527 nodes and 82,498 Tet10 elements reproduce minimum SICN -0.1083067367 and minimum sampled determinant -0.0139227176 mm³. Exactly two elements fail. Gmsh element tags are 38861 and 45699; array indices are 4560 and 11398. A hypothetical index-based native export would number them 4561 and 11399; no native model was submitted.

The complete original mesh was rechecked, including SICN P01/P05/P50, every 73-point determinant set, corner orientation and the shared-edge map. Independent scalar checks reproduce the failures. Evidence: ORIGINAL_FAILURE_METRICS.json and 00_integrity/baseline.
