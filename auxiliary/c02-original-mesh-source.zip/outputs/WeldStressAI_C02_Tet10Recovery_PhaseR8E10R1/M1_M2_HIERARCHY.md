# Achieved mesh hierarchy

Near-weld M1 median/P90 edges are0.400617341/0.412006779 mm. M2 achieves0.300664474/0.305606160 mm. Ratios are0.750502893 and0.741750319, both below the frozen0.98 ceiling. Curved-front face density increases by1.764946831.

Near-weld face counts are14,077 and24,853; curved areas are963.186977 and963.491049 mm². Overall element-density ratio is1.330177701. Parent-region edge statistics are retained separately. Both meshes have the same CAD hash and source provenance. Quadratic volume quadrature gives33,562.48701696 and33,562.49316480 mm³, a difference0.00614784 mm³. This is discretization comparison, not measured volume validation.
