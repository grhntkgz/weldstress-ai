# M2 geometry fidelity

M2 source forward P95/max are0.001842450/0.007785679 mm; reverse P95/max are0.002700924/0.024530793 mm. The same frozen measured coordinates and original T0 triangles define the reference. All geometry gates pass, and all six measured/assumed patches are classified.

M2 is a different finite quadratic approximation of the same authoritative CAD. The symmetric actual quadratic chart comparison against M1 has maximum0.011574564 mm; bounded local-patch closest diagnostic maximum is0.011532917 mm. These are actual curved-face comparisons, not corner-facet distances. Same-CAD identity and per-source fidelity gates establish domain compatibility; no unstated pair-distance tolerance was introduced.
