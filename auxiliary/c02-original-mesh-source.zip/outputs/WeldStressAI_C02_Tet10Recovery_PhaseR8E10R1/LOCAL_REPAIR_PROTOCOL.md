# Frozen local repair protocol

Strategy precedence is S1, then S2, then S3 if needed. S1 minimizes the sum of squared node displacements normalized by the local length0.663101976 mm. Only four interior midsides are variables; all corners, boundary nodes and connectivity are fixed. Shared nodes have one global position.

The first trial used a0.035 quality-margin target, a per-node displacement cap0.15 times the local length, constrained SLSQP and120 maximum iterations. Constraints cover909 frozen Q2 positions in all14 potential-support elements. Frozen acceptance remains SICN≥0.020 and strictly positive determinants; the tighter optimizer target is not a relaxed gate. Whole-mesh quality, independent SICN, scalar derivatives, topology and fresh full-source geometry checks follow optimization.

Maximum budgets remain3 strategies,3 trials per strategy,2 new full M1 candidates and2 new full M2 candidates. No native or AI execution is allowed. The exact preregistration and Q2 hash precede the local experiment.
