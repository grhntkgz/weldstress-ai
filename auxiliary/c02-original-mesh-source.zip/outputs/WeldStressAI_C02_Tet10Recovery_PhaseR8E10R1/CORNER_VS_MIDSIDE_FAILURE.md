# Corner versus quadratic failure

Both original straight corner tetrahedra have positive determinants and ordinary local aspect measures. The full ten-node mapping is nevertheless inverted at sampled corners once the measured-front curvature is represented. Individual-midside diagnostics distinguish the shared boundary midside from the remaining positions.

The accepted repair preserves that CAD-constrained midside. Instead, one of the four eligible interior midsides moves; the other three stay exactly fixed. This changes the volume interpolation while keeping all corners and the entire external quadratic surface exactly fixed. No smoothing or coordinate change is applied to the measured surface.
