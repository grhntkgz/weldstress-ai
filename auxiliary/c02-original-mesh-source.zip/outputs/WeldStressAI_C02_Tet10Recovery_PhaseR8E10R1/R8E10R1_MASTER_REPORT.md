# C02 Tet10 recovery and mesh-pair qualification

**R8E10R1_MESH_RECOVERY_COMPLETE — pre-solver mesh pair qualified; no native or AI execution.**

The invalid M1 was repaired by moving only one of four eligible interior midsides, maximum displacement0.0196508211 mm. External geometry and connectivity remained exact. One complete M1 candidate and one M2 candidate passed all frozen quality, full-source fidelity, topology, hierarchy and BVP mesh-geometry gates.

| Quantity | Recovered M1 | M2 |
|---|---:|---:|
| Nodes |145527|193962|
| Tet10 elements |82498|109737|
| Minimum SICN |0.0350000000|0.0634291190|
| Minimum Q1 detJ (mm³) |0.00444250195|0.00450120192|
| Negative/zero Q1 elements |0/0|0/0|
| Forward P95/max (mm) |0.001928801/0.008699451|0.001842450/0.007785679|
| Reverse P95/max (mm) |0.002744363/0.023077044|0.002700924/0.024530793|
| Near-weld median/P90 edge (mm) |0.400617341/0.412006779|0.300664474/0.305606160|

The root cause is a numerical curvature-placement incompatibility, not a source-geometry defect, incorrect ordering or invalid straight corner tetrahedron. The shared on-CAD boundary midside is retained. No measured surface smoothing, source deletion or threshold relaxation occurred.

## Explicit answers to the35 requested questions

**1. Were all original R8-E10 failure artifacts preserved?**

Yes. Historical E10 files and the negative baseline were preserved and hash-verified.

**2. Were the two original invalid elements reproduced?**

Yes. Both negative-Jacobian failures and the original minimum SICN were independently reproduced.

**3. What are their exact element IDs?**

Original Gmsh tags38861 and45699; array indices4560 and11398. Intended index-based native IDs would be4561 and11399, but no native export was solved.

**4. Where are they located within the standardized solid?**

NearX128.90 mm,Y31.62–31.86 mm,Z-0.12 mm, on the measured-front side; caps and rear are distant.

**5. Are their corner tetrahedra valid?**

Yes. Corner determinants are+0.1112030880 and+0.1050155577 mm³; volumes0.0185338480 and0.0175025929 mm³.

**6. Is Tet10 connectivity ordering correct?**

Yes. API local coordinates, expected edge pairs, global shared-edge identities and historical native permutation agree.

**7. Are the invalidities caused by midside placement?**

The verified contribution is the on-CAD curved boundary midside with the original straight interior layout. Ordering and corner inversion are excluded.

**8. Are the invalid elements adjacent or independent?**

They share an internal face and one connected local region. Their complete moved-node support contains14 elements.

**9. Do CAD projection or patch interfaces contribute?**

On-CAD boundary curvature contributes. Off-CAD projection and rear/cap patch junctions do not explain these failures.

**10. What is the independently verified root cause?**

Boundary curvature at shared midside15562 is incompatible with the original volume interpolation. A single-midside diagnostic isolates the contribution; the accepted repair instead preserves the boundary and moves interior midsides.

**11. Which local repair strategies were evaluated?**

S1 interior optimization was executed. S2 and S3 were registered but not needed after S1 passed.

**12. How many local trials were performed?**

One local S1 trial, one complete new M1 candidate and one independently generated M2 candidate.

**13. Which coordinates or connectivity entries changed?**

Only original Gmsh node86669 changed: deltaXYZ=(-0.004512989,+0.000673633,-0.019113710) mm. Three other eligible nodes had zero displacement. All corners, connectivity and external boundary coordinates stayed exact.

**14. Were all measured source XYZ coordinates preserved?**

Yes. All measured XYZ, IDs, triangles and T0 weights remained byte-identical.

**15. Was the original STEP geometry preserved?**

Yes. The qualified STEP hash is unchanged; no CAD generation occurred.

**16. Were measured and assumed patch interfaces preserved?**

Yes. M1 external boundary is exact; M2 independently conforms to the same six CAD patches and frozen fidelity gates.

**17. Were any original CAD face constraints violated?**

No observed boundary constraint violation. All source fidelity and patch tests pass; curved finite faces remain approximations of the CAD.

**18. Did the repaired elements become valid?**

Yes. The original two elements now have positive determinants and SICN above0.020.

**19. Did all adjacent affected elements remain valid?**

Yes. All14 potential-support elements pass expanded sampling and exact local Bernstein positivity bounds.

**20. Did the full M1 mesh pass independent quality checks?**

Yes. Whole M1 quality, independent SICN, topology and fresh full-source fidelity pass.

**21. What is the final M1 minimum SICN?**

0.0349999999912.

**22. What is the final M1 minimum sampled Jacobian?**

0.00444250194702 mm³ on the whole-mesh frozen Q1 set.

**23. Did full original-source geometry fidelity pass?**

Yes for both meshes. M1 forward/reverse maxima0.008699451/0.023077044 mm; M2 maxima0.007785679/0.024530793 mm.

**24. Was M1 qualification achieved within resource limits?**

Yes. One trial and one complete M1 candidate;145,527 nodes and82,498 elements, within all limits.

**25. Was M2 generated only after M1 qualification?**

Yes. The final M1 pass receipt was required before M2 generation.

**26. Did M2 represent the same computational geometry?**

Yes in the frozen-CAD sense. Both approximate the same unchanged STEP; their finite quadratic boundaries differ and the maximum actual chart gap0.011574564 mm is reported.

**27. Did M2 achieve meaningful near-weld refinement?**

Yes. Median/P90 edge ratios0.750502893/0.741750319 and surface-density ratio1.764946831 satisfy the frozen hierarchy.

**28. Did M2 pass all quadratic quality gates?**

Yes. M2 minimum SICN0.0634291190, minimum Q1 determinant0.00450120191734 mm³, zero negative/zero sampled determinants.

**29. Did both meshes satisfy node and element limits?**

Yes. M1:145,527/82,498 nodes/elements; M2:193,962/109,737; limits350,000/230,000.

**30. Was common BVP mesh preflight feasible?**

Yes for geometry only: port identification, moment matrices, common line, defined53,200 N convention and rank-six gauge feasibility pass. No actual load or constraint was applied.

**31. How many new native ANSYS solutions were executed?**

Zero native ANSYS jobs and zero solutions.

**32. How many AI training or inference runs were executed?**

Zero AI training and zero inference runs.

**33. Are the completed meshes ready for a conditional native ANSYS campaign?**

Conditionally yes for a separately authorized C02 native import and solve-preflight campaign. Native acceptance and stress consistency remain untested.

**34. What numerical limitations remain?**

Whole-mesh continuous positivity is not proven; only listed local elements have exact Bernstein certificates. Native shape checks, equilibrium, tensor recovery and T2 consistency remain unexecuted. Physical geometry limitations persist.

**35. What should the next authorized execution phase do?**

Preserve this pair, verify hashes and current resources, then separately authorize only C02 M1/M2 native import, shape checks, standardized BVP assembly, sequential solves and original-source T2 qualification. No automatic cohort expansion or AI training.

## Inspectable evidence

- ORIGINAL_FAILURE_METRICS.json and INVALID_ELEMENT_CONNECTIVITY.csv
- ROOT_CAUSE_HYPOTHESIS_MATRIX.csv and SINGLE_MIDSIDE_CAUSAL_DIAGNOSTICS.csv
- LOCAL_REPAIR_TRIALS.csv and LOCAL_NODE_DISPLACEMENTS.csv
- 06_recovered_M1/M1_C1 and07_refined_M2/M2_C1
- 08_quadratic_quality exact local Bernstein certificates
- 10_mesh_hierarchy/PAIR_PRE_SOLVER_QUALIFICATION.json
- 11_mechanical_mesh_preflight for un-applied BVP feasibility
- PRE_SOLVER_GATE_DECISIONS.csv and final reproducibility manifest

No V1 stress reference or training dataset is qualified by mesh checks alone. Native import, shape warnings, equilibrium, tensor accuracy and T2 numerical consistency remain unexecuted.
