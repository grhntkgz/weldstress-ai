# Local topology and support

Face-based one-ring and two-ring regions contain6 and15 elements respectively, including the two invalid elements. Both failures share one internal face. The four selected free midsides influence14 elements through their complete node-support stars, which are more inclusive than face-ring adjacency. All14 are verified after repair; no shared node is moved independently in different elements.

Local measured source IDs, XYZ and T0 weights are listed in ORIGINAL_SOURCE_POINTS_IN_LOCAL_WINDOW.csv. Boundary/interior classifications, patch distances and the unchanged geometry-only height0.5mm contour are retained. This contour is not a validated physical weld-toe track. Rear and cap interfaces are distant from the failure region.
