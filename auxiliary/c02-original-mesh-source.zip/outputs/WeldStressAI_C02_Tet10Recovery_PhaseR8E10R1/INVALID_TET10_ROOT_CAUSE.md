# Verified numerical root cause

The two invalid elements share an internal face and belong to one topological region. Their corner determinants are +0.1112030880 and +0.1050155577 mm³; corner volumes are 0.0185338480 and 0.0175025929 mm³. Minimum face angles are about31.60 degrees and edge ratios are below1.79. The corners are not inverted or degenerate.

The shared measured-front midside, Gmsh node15562, is on the frozen CAD and lies0.078674563 mm below the corresponding straight-edge midpoint. In an independent diagnostic, straightening only that midside makes both local maps positive: Q2 minima0.0987557545 and0.0730502132 mm³. This off-CAD diagnostic is not an admissible repair and was not saved as a full candidate. It isolates the numerical contribution of boundary curvature.

The supported mechanism is curved boundary placement incompatible with the original straight interior quadratic layout. Gmsh ordering, the intended SOLID187 permutation and globally shared midsides are correct. The failure is not evidence of a measured-source defect or a rear/cap junction problem. S1 subsequently restored validity by moving one eligible interior midside only. See ROOT_CAUSE_HYPOTHESIS_MATRIX.csv and SINGLE_MIDSIDE_CAUSAL_DIAGNOSTICS.csv.
