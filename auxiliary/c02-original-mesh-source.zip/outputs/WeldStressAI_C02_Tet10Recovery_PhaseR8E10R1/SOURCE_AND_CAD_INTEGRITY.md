# Source and CAD preserved

All 336 durable E10 artifacts and 158 initially frozen E9 files were hash-verified at initialization. Original C02 source XYZ, IDs, T0 triangles, area weights and normals were copied byte-for-byte. No other source was analysed. The qualified STEP SHA256 remains 811aa69622f56d6dcfac1c483b3309fc3ad974b6a82e46762770c5d488e7b80a. No CAD geometry was regenerated.

The identity source-to-computational transform and inherited numerical X/Y axes are explicit. Physical axis calibration was not newly validated. All historical roots remain read-only. Final preservation checks and the release manifest cover the exact bytes.
