# Recovered M1 quality

M1_C1 retains145,527 nodes and82,498 Tet10 elements. Minimum SICN is0.0349999999912; minimum Q1 determinant is0.00444250194702 mm³. Negative, zero and below0.020 SICN counts are all zero. All73 original points were checked for every element. Independent SICN agrees with Gmsh across the complete mesh to3.963e-13.

Q2 uses909 points on each of14 potential-support elements. Exact rational cubic Bernstein coefficients are positive for all14, with lower bound0.00444250194703 mm³. This is a continuous determinant positivity certificate for those stored local elements only. It is not a whole-mesh mathematical certificate. Node and element limits, shared identities, one connected volume, closed Euler-2 boundary and all measured/assumed patches pass.
