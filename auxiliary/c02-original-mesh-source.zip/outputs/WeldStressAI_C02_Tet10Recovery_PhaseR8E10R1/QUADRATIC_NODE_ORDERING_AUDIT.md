# Tet10 ordering audit

Gmsh type11 local coordinates were obtained from the installed API. Midpoints were matched to their corner-edge pairs. Conversion to the native-style edge order is the zero-based permutation [0,1,2,3,4,5,6,7,9,8]. Existing C02 E8B native-displacement provenance confirms this historical export convention without invoking ANSYS.

The whole original M1 edge map has122,410 unique edges and zero inconsistent shared midsides. No corner is reused as a midside. New M1 retains the original connectivity exactly; M2 independently passes the same conformity checks. See NODE_ORDERING.json and INVALID_ELEMENT_CONNECTIVITY.csv.
