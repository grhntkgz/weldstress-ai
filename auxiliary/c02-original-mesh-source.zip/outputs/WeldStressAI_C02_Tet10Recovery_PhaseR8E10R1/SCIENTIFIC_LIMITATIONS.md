# Limits of the mesh qualification

The result is pre-solver mesh qualification. It is not native ANSYS import acceptance, equilibrium, stress tensor accuracy, T2 convergence or a qualified V1 learning label. ANSYS and AI run counts are zero. Only C02 was analysed. Historical G08/X10 work was not resumed.

Whole-mesh Jacobian positivity is sampled at the frozen73 points. Expanded local checks and exact rational local Bernstein bounds strengthen the evidence, but do not certify continuous positivity of the entire mesh. SICN is also a sampled metric. Gmsh parameter metadata warnings are preserved; the exact labelled mesh round trip does not certify future CAD reparameterization.

The frozen CAD and source retain prior registration, physical-axis, actual rear/thickness and notch-radius limitations. No physical stress, residual stress, plasticity, fatigue life or independent AI generalization claim follows. The official Gmsh method documentation describes the sampled SICN API; the version-pinned primary implementation is retained under01_frozen_protocol/reference_code.
