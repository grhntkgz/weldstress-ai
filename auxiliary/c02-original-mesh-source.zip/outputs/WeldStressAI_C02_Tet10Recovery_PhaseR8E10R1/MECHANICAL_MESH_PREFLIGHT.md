# Mechanical mesh geometry preflight

Both meshes preserve global-X tension, global-Y weld direction, full28 mm Y span, documented nominal19 mm thickness and the frozen parent-midpoint line atY30 andZ-9.37643484024406 mm. Defined reference force is53,200 N. Port surfaces are identifiable, their quadratic moment matrices have rank3 and their intended affine traction ranges remain within50–150 MPa.

All three original gauge corner locations are present; the six proposed scalar rigid-mode constraints have rank6. This phase only checks geometry and integration feasibility. No nodal force or displacement constraint was applied, no input deck or native job was submitted and no force/moment equilibrium was claimed. Native import, shape warnings and all stress/T2 checks remain for a separately authorized phase.
