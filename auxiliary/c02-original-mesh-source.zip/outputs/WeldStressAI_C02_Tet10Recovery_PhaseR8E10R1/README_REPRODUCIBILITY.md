# Reproducibility and review

The original invalid M1, source arrays and qualified STEP are copied under00_integrity and01_frozen_protocol with original hashes. New M1 and M2 NPZ files contain actual nodes, Tet10 connectivity, surface Tri6 connectivity, tags and quality. Each folder also contains raw and explicitly labelled MSH exports, fidelity arrays and pass receipts. Different serializations of the same coordinates/connectivity are one candidate, not additional mesh trials.

The local repair preregistration and trial/candidate ledgers are immutable release evidence. Use the existing Phase5E Python runtime with-B. New code lives only in this R1 directory. Source routines deny historical writes and external process launches, including native solvers. Review the release with the independent standard-library verifier --dry-run; do not rerun generators inside a sealed release.

Exact Fraction Bernstein coefficients, independent scalar Jacobians and an independent SICN formula are inspectable. Main methods: [Gmsh4.15.2 API](https://gmsh.info/doc/texinfo/gmsh.html) and [version-pinned condition-number implementation](https://raw.githubusercontent.com/gmsh-project/gmsh/gmsh_4_15_2/src/numeric/CondNumBasis.cpp). A supplementary GradientBasis.cpp download returned404; it was not required or used. The required condition-number source and numerical cross-checks are present.
