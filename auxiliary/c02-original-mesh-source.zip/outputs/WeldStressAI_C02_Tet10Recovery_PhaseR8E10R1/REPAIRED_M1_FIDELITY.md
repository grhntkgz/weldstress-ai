# M1 geometry fidelity

All original source arrays and the STEP are unchanged. Every external M1 mesh node, every corner and all connectivity entries are exactly identical to the original M1. Fresh full-source forward P95/max are0.001928801/0.008699451 mm. Reverse values are0.002744363/0.023077044 mm. All frozen0.010/0.040 mm gates pass.

These values match the original surface because S1 changes only interior interpolation. Actual curved-patch closest diagnostics and full patch classification were also evaluated. Local closest searches are not certified global closest distances and never substitute for the same-XY gates. Source IDs and weights remain bitwise preserved.
